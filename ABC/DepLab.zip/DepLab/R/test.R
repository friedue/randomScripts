#' Reading in MaxQuant output
#' 
#' @description 
#' test
#' 
#' @param filename path to MaxQuant output file
#' 
#' 
#' @export
reading_MQ <- function(filename){
  
  mq.in <- read.table(filename, header=TRUE, sep="\t",
                      strip.white = TRUE, fill = TRUE, stringsAsFactors = FALSE,
                      comment.char = "") # important setting to also capture 
  #cases with "#" in the Fasta header
  
  return(mq.in)
  
}
