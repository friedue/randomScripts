# This is the user-interface definition of a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library(shiny)
library(ggplot2)
library(scales)
library(colorspace)
#library(plotly)
library(shinyBS)
library(shinyFiles)
library(shinythemes)


shinyUI(
  #            navbarPage(theme = shinytheme("Flatly"), "PCP",
  navbarPage( "PCP",
              
              tabPanel("Data Import",
                       h1("Select database"),
                        shinyFilesButton( 'db_path' ,  'Select database' ,  'Please select database file' , FALSE),
                       textOutput('db_dir_path'),
                     
                       helpText("If you do not wish to upload new data, simply continue to the visualization tab."),
                       br(),
                      h1("Upload new experiment"),
                       h2("Upload Maxquant data"),
                       fileInput('file1', 'Choose File',
                                 accept=c('text/csv', 
                                          'text/comma-separated-values,text/plain', 
                                          '.csv')),
                       fluidRow(column(4, textInput("expt.id", label = "Expt ID", value = "")),
                                column(4,selectInput("organism", label = "Organism", choices = list("human", "yeast"),selected = "human"))
                       ),
                       fluidRow(
                         column(4,
                                textInput("id_for_standard", label = "Enter comma-separated list of Uniprot ID(s) to use as standard (optional)", value = ""),
                                
                                tags$head(
                                  tags$style(HTML('#saveButton{background-color: #E77471}'))
                                ),
                                
                                actionButton("saveButton", "Save")),
                         column(4, bsAlert("alert"))),
                       
                       #br(),
                       #br(),
                       #br(),
                       h2("Sample origin and preparation"),
                       textInput("experimenter.name",
                                 label = "Name of experimenter",
                                 value = ""),
                       fluidRow(
                         column(4,textInput("genotype",
                                            label = "Genotype",
                                            value = ""))
                       ),
                       fluidRow(
                         column(4,dateInput("harvest.date",
                                            label="Harvest date")),
                         column(4,selectInput("buffer.composition",
                                              label = "Buffer composition",
                                              choices = list("none"),
                                              selected = "None")),
                         column(4,selectInput("lysis.method",
                                              label = "Lysis method",
                                              choices = list("none"),
                                              selected = "None")),
                         column(4,selectInput("protein.assay.method",
                                              label = "Protein assay method",
                                              choices = list("none"),
                                              selected = "None")),
                         column(4,numericInput("protein.concentration",
                                               label = "Concentration (uM)",
                                               value = 1)),
                         column(4,selectInput("digestion.enzyme",
                                              label = "Digestion enzyme",
                                              choices = list("none"),
                                              selected = "None")),
                         column(4,textInput("digestion.conditions",
                                            label = "Digestion conditions",
                                            value = "")),
                         column(4,textInput("notes",
                                            label = "Notes",
                                            value = ""))
                       ),
                       
                       h2("Prefractionation method"),
                       textInput("column.id",label = "Column ID",value = ""),
                       fluidRow(
                         column(4,numericInput("amount.protein.loaded",
                                               label = "Amount of protein loaded (ug)",
                                               value = 1)),
                         column(4,numericInput("sample.vol.loaded",
                                               label = "Sample volume loaded (ul)",
                                               value = 1)),
                         column(4,selectInput("lc.method",
                                              label = "LC method",
                                              choices = list("none"),
                                              selected = "None")),
                         column(4,numericInput("lc.flow.rate",
                                               label = "LC flow rate",
                                               value = 1)),
                         column(4,numericInput("lc.fraction.size",
                                               label = "LC fraction size (ml)",
                                               value = 1)),
                         column(4,numericInput("time.per.fraction",
                                               label = "Time per fraction (s)",
                                               value = 1)),
                         column(4,numericInput("fractions.collected",
                                               label = "Number of fractions collected",
                                               value = 1))
                       ),
                       fileInput('chrom_image', 'Choose Chromatogram Image', accept=c('image/png')),
                       imageOutput("preImage", inline = TRUE),
                       
                       h2("Mass spectrometry method"),
                       textInput("instrument.id",label = "Instrument ID",value = ""),
                       fluidRow(
                         column(4,dateInput("run.date",
                                            label = "Run date")),
                         column(4,textInput("data.file.name",
                                            label = "Data file",
                                            value = "")),
                         column(4,textInput("method.file.name",
                                            label = "Method file",
                                            value = "")),
                         column(4,numericInput("method.length",
                                               label = "Length of method (s)",
                                               value = 1)),
                         column(4,selectInput("quantitative.method",
                                              label = "Quantitative method",
                                              choices = list("LFQ"),
                                              selected = "LFQ"))
                       ),
                       
                       h2("Data processing"),
                       fluidRow(
                         column(4,selectInput("processing.platform",
                                              label = "Processing platform",
                                              choices = list("core", "maxquant", "OPEN-MS"),
                                              selected = "maxquant")),
                         column(4,selectInput("search.algorithm",
                                              label = "Search algorithm",
                                              choices = list("none"),
                                              selected = "None")),
                         column(4,selectInput("flitering.algorithm",
                                              label = "Filtering algorithm",
                                              choices = list("none"),
                                              selected = "None")),
                         column(4,selectInput("flitering.stringency",
                                              label = "Filtering stringency",
                                              choices = list("none"),
                                              selected = "None"))
                       ),
                       
                       # contains the reactively rendered output, dependent on selected widget elements
                       h2("Summary"),
                       br()
                       
              ),
              tabPanel("Visualization",
                       tabsetPanel("Panel 1.x",
                                   
                                   tabPanel("Summary plots",
                                            sidebarLayout(
                                              
                                              # Sidebar with a slider input
                                              wellPanel(
                                                tags$style(type="text/css", '#leftPanel { width:250px; float:left;}'),
                                                id = "leftPanel",
                                                helpText("Select the relevant variable conditions"),
                                                selectizeInput('show_expt_id_sum', 'Select expt ID', choices = NULL,  selected =  NULL, multiple=TRUE),  
                                                
                                                selectInput("y_axis_choices_sum", label = ("y variable"), 
                                                            choices = list("Raw intensity" = "raw.intensity",
                                                                           "LFQ intensity" = "LFQ.intensity", 
                                                                           "MS count" = "MS.MS.count", 
                                                                           "Peptides count"= "peptides.count", 
                                                                           "Unique peptides only" ="unique.peptides.only",
                                                                           "Razor and unique peptides" = "razor.and.unique.peptides",
                                                                           "Sequence coverage" ="sequence.coverage"), 
                                                            selected = "raw.intensity") ,
                                                checkboxGroupInput("y_axis_log_2",
                                                                   label = "y transformation",
                                                                   choices = "log2"),
                                                selectInput("split_by_summary", label = ("Split into rows by"), 
                                                            choices = list("None" = "none", "Expt ID" = "expt_id"), 
                                                            selected = "expt_id"),
                                                sliderInput("summary_x_interval", "x interval", 1, 50, 5),
                                                textInput("plot_summary_title", label = "Plot title", value = ""),
                                                actionButton("colorButton2", "Change colors"),
                                                shinySaveButton('save', 'Save plot', 'Save plot as...', filetype=list(pdf=c('pdf'), png=c('png')))
                                                
                                              ),
                                              # Show a plot of the generated distribution
                                              mainPanel(
                                                plotOutput("plot_summary",
                                                           #  height ="auto",
                                                           height = 600,
                                                           width="100%",
                                                           dblclick = "proteasomeSummaryPlot_dblclick",
                                                           brush = brushOpts(
                                                             id = "proteasomeSummaryPlot_brush",
                                                             resetOnNew = TRUE))
                                              )
                                            )),
                                   
                                   
                                   
                                   
                                   
                                   tabPanel("Individual proteins",            
                                            sidebarLayout(
                                              # side panel contains the variable selection widgets
                                              wellPanel(
                                                tags$style(type="text/css", '#leftPanel { width:250px; float:left;}'),
                                                id = "leftPanel",
                                                helpText("Select the relevant variable conditions"),
                                                selectizeInput('show_expt_id', 'Select expt ID', choices = NULL,  selected =  NULL, multiple=TRUE),
                                                textOutput("current_organism"),
                                                # gene symbol to view
                                                selectizeInput('show_gene_symbol', 'Select gene symbol', choices = NULL,  selected =  NULL, multiple=TRUE),  
                                                actionLink("save_as_complex", "save as complex..."),
                                                radioButtons(inputId="complex_source", label="Select complex from", choices=list("Benschop (Sc)" = "benschop","Wodak (Sc)" = "wodak", "PCDq (Hs)" = "pcdq", "Custom" = "custom"), inline=TRUE),
                                                ### bs modal for save group of genes as complex
                                                bsModal("save_as_complex_modal", "Save as...", "save_as_complex", size="small", 
                                                        textInput("new.complex.name",
                                                                  label = "Save complex as ",
                                                                  value = ""),
                                                        bsButton("saveModalButton", label = "Save",  icon = icon("ban"))
                                                ),
                                                
                                                htmlOutput("complexChoices"),
                                                selectInput("y_axis_choices", label = ("y variable"), 
                                                            choices = list("Raw intensity" = "raw.intensity",
                                                                           "LFQ intensity" = "LFQ.intensity", 
                                                                           "MS count" = "MS.MS.count", 
                                                                           "Peptides count"= "peptides.count", 
                                                                           "Unique peptides only" ="unique.peptides.only",
                                                                           "Razor and unique peptides" = "razor.and.unique.peptides",
                                                                           "Sequence coverage" ="sequence.coverage"), 
                                                            selected = "raw.intensity"),
                                                checkboxGroupInput("y_axis_log",
                                                                   label = "y transformation",
                                                                   choices = c("log2", "normalize across fractions", "normalize by spike-in")),
                                                uiOutput("uiRadio"),
                                                selectInput("split_by", label = ("Split into rows by"), 
                                                            choices = list("None" = "none", "Gene symbol" = "gene_symbol", "ID" = "id", "Expt ID" = "expt_id", "Complex" = "complex"), 
                                                            selected = "expt_id"),
                                                selectInput("split_by_col", label = ("Split into columns by"), 
                                                            choices = list("None" = "none", "Gene symbol" = "gene_symbol", "ID" = "id",  "Expt ID" = "expt_id", "Complex" = "complex"), 
                                                            selected = "none"),
                                                selectInput("color_by_choices", label = ("Color by"), 
                                                            choices = list("Gene symbol" = "gene_symbol", "ID" = "id", "Expt ID" = "expt_id", "Complex" = "complex"), 
                                                            selected = "gene_symbol"),
                                                selectInput("pointShape", label = ("Point shape"), 
                                                            choices = list("dot" = 16, "square" = 15, "plus" = 3, "cross" = 4, "diamond" = 18,
                                                                           "Assign to gene symbol" = "gene_symbol", "Assign to ID" = "id", 
                                                                           "Assign to expt ID" = "expt_id", "Assign to complex" = "complex"), 
                                                            selected = 16),
                                                sliderInput("pointSize", "Point size", 0, 10, 1),
                                                
                                                selectInput("lineType", label = ("Line type"), 
                                                            choices = list("solid" = 1, "dashed" = 2, "dotted" = 3, 
                                                                           "Assign to gene symbol" = "gene_symbol", "Assign to ID" = "id", 
                                                                           "Assign to complex" = "complex"), 
                                                            # "Assign to expt ID" = "expt_id",
                                                            selected = 1),
                                                sliderInput("lineSize", "Line size", 0, 10, 1),
                                                
                                                textInput("plot_title", label = "Plot title", value = ""),
                                                actionButton("colorButton", "Change colors"),
                                                
                                                shinySaveButton('save', 'Save plot', 'Save plot as...', filetype=list(pdf=c('pdf'), png=c('png')))
                                              ), # ends wellPanel
                                              
                                              # main panel contains the reactively rendered output, dependent on selected widget elements
                                              mainPanel(
                                                
                                                plotOutput("plot_proteasome",
                                                           #                                        height = 800,
                                                           #                                        width=1000,
                                                           #height = "auto",
                                                           height = 600,
                                                           
                                                           width="100%",
                                                           dblclick = "proteasomePlot_dblclick",
                                                           brush = brushOpts(
                                                             id = "proteasomePlot_brush",
                                                             resetOnNew = TRUE)),
                                                h1('      '),
                                                br(),br(),br(),br(),
                                                uiOutput('retrieve_protein_button'),
                                                div(tableOutput("prot_table"), style = "font-size:80%"),
                                                tags$head(tags$style(type="text/css", "#prot_table table td {line-height:50%;}"))
                                                
                                              )  # ends mainPanel
                                            )  # ends sidebarLayout
                                   ),
                                   
                                   tabPanel("Spike-in quantification",
                                            sidebarLayout(
                                              # Sidebar with a slider input
                                              wellPanel(
                                                tags$style(type="text/css", '#leftPanel { width:250px; float:left;}'),
                                                id = "leftPanel",
                                                helpText("Select the relevant variable conditions"),
                                                selectizeInput('show_expt_id_std', 'Select expt ID', choices = NULL,  selected =  NULL, multiple=TRUE),  
                                                selectizeInput('show_trypsin_symbol', 'Select UniProt ID', choices = NULL,  selected =  NULL, multiple=TRUE),  
                                                selectInput("y_axis_choices_tryp", label = ("y variable"), 
                                                            choices = list("Raw intensity" = "raw.intensity",
                                                                           "LFQ intensity" = "LFQ.intensity", 
                                                                           "MS count" = "MS.MS.count", 
                                                                           "Peptides count"= "peptides.count", 
                                                                           "Unique peptides only" ="unique.peptides.only",
                                                                           "Razor and unique peptides" = "razor.and.unique.peptides",
                                                                           "Sequence coverage" ="sequence.coverage"), 
                                                            selected = "raw.intensity") ,
                                                checkboxGroupInput("y_axis_log_tryp",
                                                                   label = "y transformation",
                                                                   choices = c("log2", "normalize across fractions")),
                                                selectInput("split_by_std", label = ("Split into rows by"), 
                                                            choices = list("None" = "none", "UniProt ID" = "id", "Expt ID" = "expt_id"), 
                                                            selected = "expt_id"),
                                                selectInput("split_by_std_col", label = ("Split into columns by"), 
                                                            choices = list("None" = "none", "UniProt ID" = "id", "Expt ID" = "expt_id"), 
                                                            selected = "none"),
                                                selectInput("color_by_choices_std", label = ("Color by"), 
                                                            choices = list("UniProt ID" = "id", "Expt ID" = "expt_id"), 
                                                            selected = "id"),
                                                
                                                textInput("plot_tryp_title", label = "Plot title", value = ""),
                                                actionButton("colorButton_tryp", "Change colors"), 
                                                shinySaveButton('save', 'Save plot', 'Save plot as...', filetype=list(pdf=c('pdf'), png=c('png')))
                                                
                                              ),
                                              # Show a plot of the generated distribution
                                              mainPanel(
                                                #plotlyOutput("plot_trypsin"),
                                                plotOutput("plot_trypsin",
                                                           #  height = "auto",
                                                           height = 600,
                                                           width="100%",
                                                           dblclick = "proteasomeTrypsinPlot_dblclick",
                                                           brush = brushOpts(
                                                             id = "proteasomeTrypsinPlot_brush",
                                                             resetOnNew = TRUE)),
                                                h1('      '),
                                                br(),br(),br(),br(),
                                                # br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),
                                                uiOutput('retrieve_protein_std_button'),
                                                div(tableOutput("std_prot_table"), style = "font-size:80%"),
                                                tags$head(tags$style(type="text/css", "#prot_table table td {line-height:50%;}"))
                                                
                                                #   div(tableOutput("tryp_table"), style = "font-size:80%"),
                                                #    tags$head(tags$style(type="text/css", "#tryp_table table td {line-height:50%;}"))
                                              )
                                            ))
                                   
                                   
                                   
                       )), # ends plot tabPanel
              
              
              tabPanel("Tables", # shows complete metadata and data tables
                       tabsetPanel(
                         id = 'datasets',
                         tabPanel('Summary plots',shinySaveButton('save_sum_table', 'Export', 'Export table as...', filetype=list(csv=c('csv'))), h3('  '), dataTableOutput('summarydata')),
                         tabPanel('Individual proteins',shinySaveButton('save_indiv_table', 'Export', 'Export table as...', filetype=list(csv=c('csv'))), h3('  '), dataTableOutput('proteasomedata')),
                         tabPanel('Spike-in quantification',  shinySaveButton('save_std_table', 'Export', 'Export table as...', filetype=list(csv=c('csv'))), h3('  '), dataTableOutput('standardsedata'))
                       ) # ends tabsetPanel
              ) # ends tables tabPanel
  )
)
