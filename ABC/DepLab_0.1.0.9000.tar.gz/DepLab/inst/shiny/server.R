
# This is the server logic for a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library(shiny)
library(ggplot2)
library(scales)
library(colorspace)
library(scales)
library(shinyBS)
library(shinyFiles)
library(stringr)
library(shinythemes)
library(RSQLite)
#library(shinyjs)

# load code to be run once (at app launch)


options(stringsAsFactors = FALSE)

benschop_complexes <- DepLab::read_complexes(filename = system.file("extdata", "defined_complexes", "complexes_benschop.txt", package = "DepLab"),
                                  organism = "yeast")
wodak_complexes <- DepLab::read_complexes(filename = system.file("extdata", "defined_complexes", "complexes_wodak.txt", package = "DepLab"),
                                  organism = "yeast")
corum_complexes <- DepLab::read_complexes(filename = system.file("extdata", "defined_complexes", "human_complexes_corum.tab", package = "DepLab"),
                                  organism = "human")


if (file.size(system.file("extdata","path_to_db.txt",package = "DepLab")) == 0){
  if( .Platform$OS.type == "windows"){
    platform_path <- file.path(Sys.getenv("USERPROFILE"), "Desktop/proteomics.db")
  } else {
    platform_path <- "~/Desktop/proteomics.db"
  }
  write.table(platform_path, system.file("extdata","path_to_db.txt",package = "DepLab"), col.names=F, row.names=F) 
}

path_to_db <- read.table(file = system.file("extdata","path_to_db.txt",
                                            package = "DepLab"),
                         sep="\t", stringsAsFactors=FALSE,
                         header=FALSE, quote="\"")

if (file.size(system.file("extdata","path_to_custom_complexes.txt",package = "DepLab")) == 0){
  if( .Platform$OS.type == "windows"){
    platform_path <- file.path(Sys.getenv("USERPROFILE"), "Desktop/complexes_custom.txt")
  } else {
    platform_path <- "~/Desktop/complexes_custom.txt"
  }
  write.table(platform_path, system.file("extdata","path_to_custom_complexes.txt",package = "DepLab"), col.names=F, row.names=F) 
}

path_to_custom_complexes <- read.table(file = system.file("extdata","path_to_custom_complexes.txt",
                                            package = "DepLab"),
                         sep="\t", stringsAsFactors=FALSE,
                         header=FALSE, quote="\"")


custom_complexes_name <- normalizePath(path_to_custom_complexes$V1, winslash = .Platform$file.sep)

database.name <- normalizePath(path_to_db$V1, winslash = .Platform$file.sep)

if(file.info(database.name)$size == 0 || is.na(file.info(database.name)$size)) {
  cur_frac_table_length <- 0
} else {
  cur_frac_table_length <- as.numeric(dbGetQuery(conn = dbConnect(SQLite(), dbname = database.name, cache_size = 5000), "SELECT MAX(_ROWID_) FROM frac_data LIMIT 1;")[1])
}

#database.name <- system.file("extdata", "proteomics.db", package = "DepLab")

radio_list <- list()

if(file.info(custom_complexes_name)$size == 0 || is.na(file.info(custom_complexes_name)$size)) {
  newDF <- data.frame("id"= "id", "gene symbol"="gene_symbol", "complex"="complex")
  write.table(newDF, custom_complexes_name, append = FALSE, row.names = FALSE, col.names = FALSE, na = "NA", quote=F, sep="\t")
} 

if(file.info(database.name)$size == 0 || is.na(file.info(database.name)$size)) {
  initialize.database(database.name, organism = "human", force = FALSE)
  initialize.database(database.name, organism = "yeast", force = FALSE)
} 

shinyServer(function(input, output, session) {
  options(shiny.maxRequestSize=30*1024^2) 
  # load code to be run when a page is visited
  volumes <- getVolumes() #c('R Installation'=R.home())
  shinyFileSave(input, 'save', roots=volumes, session=session)
  saveFileName <- renderPrint({parseSavePath(volumes, input$save)})
  observeEvent( input$save, {
    savePath <- strsplit(saveFileName(), " pdf | png ", fixed = FALSE, perl = FALSE, useBytes = FALSE)[[1]][2]
    ggsave(savePath)
  })
  
  output$downloadPlot <- downloadHandler(
    filename = function() {
      paste("plot", "pdf", sep = ".")
    },
    content = function(file) {
      ggsave(filename = file, device = "pdf", width=10, height=10)
    }
  )

  output$downloadPlot2 <- downloadHandler(
    filename = function() {
      paste("plot", "pdf", sep = ".")
    },
    content = function(file) {
      ggsave(filename = file, device = "pdf", width=10, height=10)
    }
  )
  
  output$downloadPlot3 <- downloadHandler(
    filename = function() {
      paste("plot", "pdf", sep = ".")
    },
    content = function(file) {
      ggsave(filename = file, device = "pdf", width=10, height=10)
    }
  )
  
  
  shinyFileChoose(input,  'db_path' , session=session, roots=volumes, filetypes=c('db' ))
  dbPathName <- renderText({  unlist(parseFilePaths(volumes, input$db_path))   })   #$datapath[1])
  
  database.name.reactive <- reactiveValues(data = database.name)

  observeEvent( input$db_path, {
    database.name.reactive$data <- gsub(".*  (.+)","\\1",dbPathName())
    write.table( normalizePath(gsub(".*  (.+)","\\1",dbPathName()), winslash=.Platform$file.sep) , system.file("extdata","path_to_db.txt",package = "DepLab"), row.names=F, col.names=F)
    updateSelectizeInput(session, 'show_expt_id', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
    updateSelectizeInput(session, 'show_expt_id_std', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
    updateSelectizeInput(session, 'show_trypsin_symbol', choices = DepLab:::list.std.gene.symbols(database.name.reactive$data)$id, server = TRUE)
    updateSelectizeInput(session, 'show_expt_id_sum', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
    updateSelectizeInput(session, 'show_expt_id_db_browser', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
    
  })
  

    output$db_dir_path <- renderText({ 
      paste("Currently selected database:", database.name.reactive$data, sep = "\n")
    })
  
    output$expt_id_list <- renderText({ 
      expt_id_msg <- paste("The currently selected database contains the following data sets from previous sessions:", paste(as.data.frame(DepLab:::list.expt.ids.w.organism(database.name.reactive$data))$expt_id, collapse="\n"), sep = "\n")
    })
    

    shinyFileChoose(input,  'custom_complexes_path' , session=session, roots=volumes, filetypes=c('txt' ))
    customComplexesPathName <- renderText({  unlist(parseFilePaths(volumes, input$custom_complexes_path))   })   #$datapath[1])
    
    custom.complexes.name.reactive <- reactiveValues(data = custom_complexes_name)
    
    observeEvent( input$custom_complexes_path, {
      custom.complexes.name.reactive$data <- gsub(".*  (.+)","\\1",customComplexesPathName())
      write.table( normalizePath(gsub(".*  (.+)","\\1",customComplexesPathName()), winslash = .Platform$file.sep) , system.file("extdata","path_to_custom_complexes.txt",package = "DepLab"), row.names=F, col.names=F)
      custom_complexes <- reactiveValues(data = read.table(file=custom.complexes.name.reactive$data, sep = "\t", stringsAsFactors = FALSE, header = TRUE))
      if (input$complex_source == "custom") {
        updateSelectizeInput(session, 'show_complex', choices = c(unique(custom_complexes$data$complex)))
      } 
      #print(custom_complexes$data)
    })
    
    output$custom_complexes_dir_path <- renderText({ 
      paste("The path to store custom complexes is set to:", custom.complexes.name.reactive$data, sep = "\n")
    })
    
    
  #updateSelectizeInput(session, 'show_complex', choices = c(unique(benschop_complexes$data$complex)))
  
  observeEvent( input$y_axis_choices, {
    if (input$y_axis_choices == "raw.intensity"){
      updateCheckboxGroupInput(session, "y_axis_log",  choices = c("log2", "normalize across fractions", "normalize by spike-in", "smooth lines"))
    } else {
      updateCheckboxGroupInput(session, "y_axis_log",  choices = c("log2"))
    }
  })
  
  custom_complexes <- reactiveValues(data = read.table(file=custom_complexes_name, sep = "\t", stringsAsFactors = FALSE, header = TRUE))
  
  fileName<-reactive({
    inFile <- input$chrom_image
    inFile$datapath
  })
  
  
  vars = reactiveValues(protein_counter = 0, pro_info_table = NULL)
  
  output$retrieve_protein_button <- renderUI({
    if(!is.null(input$show_expt_id)){
      if (is.null(input$show_gene_symbol) & is.null(input$show_complex)){
        return()
      } else {
        actionLink("retrieve_protein_info", label=retrieve_protein_button_label())
      }
    }
  })
  
  
  observeEvent( input$show_gene_symbol, {
    if(is.null(input$show_gene_symbol) & is.null(input$show_complex)){
      vars$protein_counter <-  0
    }
  }, ignoreNULL=FALSE)
  
  
  observeEvent(c(input$show_expt_id, input$y_axis_log), {
    if(is.null(input$show_expt_id)){
      radio_list <- NULL
    } else if (!any(grepl("spike", c(input$y_axis_log)))){
      radio_list <- NULL
    } else {
      len_expt <- length(input$show_expt_id)
      for (i in 1:len_expt){
        rad_nm <- paste0("radio_var", i)
        radio_list[[rad_nm]] <- radioButtons(rad_nm, input$show_expt_id[i], choices = (DepLab:::list.selected.std.gene.symbols(database.name.reactive$data, input$show_expt_id[i])$id), inline=TRUE)   
      }
    }
    output$uiRadio <- renderUI({
      tagList(list(radio_list))
    })
  }, ignoreNULL=FALSE)
  
  
  observeEvent(input$retrieve_protein_info, {
    if(!is.null(input$retrieve_protein_info)){
      input$retrieve_protein_info
      isolate({
        vars$protein_counter <-  vars$protein_counter + 1
      })
    }
  })
  
  ## timer
  reac <- reactiveValues(redraw = TRUE, show_gene_symbol = isolate(input$show_gene_symbol), show_expt_id =  isolate(input$show_expt_id), show_complex =  isolate(input$show_complex))
  
  observe({
    input$show_gene_symbol
    input$show_expt_id
    input$show_complex
    reac$redraw <- FALSE
  })
  
  observe({
    invalidateLater(1000, session)
    input$show_gene_symbol
    input$show_expt_id
    input$show_complex
   # input$redraw
  #  isolate(cat(reac$redraw, input$show_gene_symbol, "\n"))
    if (isolate(reac$redraw)) {
      reac$show_gene_symbol <- input$show_gene_symbol
      reac$show_expt_id <- input$show_expt_id
      reac$show_complex <- input$show_complex
    } else {
      isolate(reac$redraw <- TRUE)
    }
  })
  
  ###
  
  ### timer for sum page
  reacSum <- reactiveValues(redrawSum = TRUE, show_expt_id_sum = isolate(input$show_expt_id_sum))
  
  observe({
    input$show_expt_id_sum
    reacSum$redrawSum <- FALSE
  })
  
  observe({
    invalidateLater(1000, session)
    input$show_expt_id_sum
    if (isolate(reacSum$redrawSum)) {
      reacSum$show_expt_id_sum <- input$show_expt_id_sum
    } else {
      isolate(reacSum$redrawSum <- TRUE)
    }
  })
  
  ###
  
  retrieve_protein_button_label <- reactive({
    if(vars$protein_counter >= 1) label <- "Refresh UniProt info..."
    else label <- "Retrieve info from UniProt..."
  })
  
  
  observe({
    if(is.null(fileName())) return(NULL)
    output$preImage <- renderImage({
      filename <- fileName()
      # Return a list containing the filename and alt text
      list(src = filename,
           contentType = 'image/png',
           width = 400,
           height = 300,
           alt = "chromatogram")
      
    }, deleteFile = FALSE)
  })
  
  # ===================
  # Data input tab:
  # makes sure the currently selected variables are used to populate the vbnc data frame
  datasetInput <- reactive({
    num.replicates <- input$replicate.number
    if (input$stress.deviation == "None") {
      stress.deviation <- list(stress.deviation = "None",
                               stress.deviation.value = NA,
                               stress.deviation.unit = NA)
    } else {
      stress.deviation <- list(stress.deviation = input$stress.deviation,
                               stress.deviation.value = input$stress.deviation.value,
                               stress.deviation.unit = input$stress.deviation.unit)
    }
    
    if (input$resuscitation.media == "None") {
      resuscitation <- list(resuscitation.media = NA,
                            resuscitation.media.supplement = NA,
                            resuscitation.media.treatment = NA,
                            resuscitation.media.treatment.value = NA,
                            resuscitation.media.treatment.unit = NA)
    } else {
      if (input$resuscitation.media.supplement == "None") {
        resuscitation <- list(resuscitation.media = input$resuscitation.media,
                              resuscitation.media.supplement = NA,
                              resuscitation.media.treatment = NA,
                              resuscitation.media.treatment.value = NA,
                              resuscitation.media.treatment.unit = NA)
      } else {
        if (input$resuscitation.media.treatment == "None") {
          resuscitation <- list(resuscitation.media = input$resuscitation.media,
                                resuscitation.media.supplement = input$resuscitation.media.supplement,
                                resuscitation.media.treatment = NA,
                                resuscitation.media.treatment.value = NA,
                                resuscitation.media.treatment.unit = NA)
        } else {
          resuscitation <- list(resuscitation.media = input$resuscitation.media,
                                resuscitation.media.supplement = input$resuscitation.media.supplement,
                                resuscitation.media.treatment = input$resuscitation.media.treatment,
                                resuscitation.media.treatment.value = input$resuscitation.media.treatment.value,
                                resuscitation.media.treatment.unit = input$resuscitation.media.treatment.unit)
        }
      }
    }
    
    new.row <- c(read.time = input$read.time,
                 culture.strain = input$culture.strain,
                 stress.media = input$stress.media,
                 stress.duration = input$stress.duration,
                 stress.deviation,
                 specimen.vessel = input$specimen.vessel,
                 treatment = input$treatment,
                 treatment.value = input$treatment.value,
                 treatment.unit = input$treatment.unit,
                 treatment.exposure.time = input$treatment.exposure.time,
                 times.washed = input$times.washed,
                 vol.washing.buffer = input$vol.washing.buffer,
                 resuscitation)
    
    for (i in 1:num.replicates) {
      expt.id <- paste(input$stress.media,
                       input$treatment,
                       paste(input$stress.duration, "d", sep=""),
                       input$resuscitation.media,
                       LETTERS[i], sep="_")
      row <- c(expt.id = expt.id, replicate.number = LETTERS[i], new.row)
      vbnc <- rbind(vbnc, row)
    }
    return(vbnc)
  })
  
  output$newdata <- renderTable({
    dataset <- datasetInput()
    dataset
  })
  
  
  output$helptextsave <- renderUI({
    if(is.null(input$expt.id)){
      helpText('Select expt ID')
    }
  })
  
  

  ## dynamic UI for DB editor
  inserted <- character(0)
  
  observeEvent(input$EditButton, {
    if(input$show_expt_id_db_browser != ""){
      btn <- input$EditButton
      id <- paste0('txt', btn)
      updateButton(session, "EditButton", disabled = TRUE)
      updateButton(session, "deleteButton", disabled = TRUE)
      
    insertUI(
      selector = '#placeholderEditButtons',
      ui = tags$div(
        textInput("edit.expt.id", label = "Expt ID", value = input$show_expt_id_db_browser) ,
        selectInput("edit.organism", label = "Organism", choices = list("human", "yeast") ,selected = DepLab:::list.organism.by.expt.v2(database.name.reactive$data, input$show_expt_id_db_browser)  ),
        actionButton("saveEditsButton", "Save changes"),  actionButton("cancelEditsEbutton", "Cancel"),
        bsAlert("saveEditAlert"),
        id = id
      )
    )
    inserted <<- c(id, inserted)
    }
  })
  
  observeEvent(input$show_expt_id_db_browser, {
    updateTextInput(session, 'edit.expt.id', value = input$show_expt_id_db_browser)
    updateSelectInput(session, 'edit.organism', selected = DepLab:::list.organism.by.expt.v2(database.name.reactive$data, input$show_expt_id_db_browser))
  })
  
  observeEvent(input$saveEditsButton, {
    createAlert(session, "saveEditAlert", "savEdAlert", title = "Saving",
                content = "Saving changes to database.. This might take a while....", append = FALSE)
    DepLab:::update.expt(database.name.reactive$data, input$show_expt_id_db_browser, input$edit.expt.id, input$edit.organism )
    updateSelectizeInput(session, 'show_expt_id', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
    updateSelectizeInput(session, 'show_expt_id_std', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
    updateSelectizeInput(session, 'show_trypsin_symbol', choices = DepLab:::list.std.gene.symbols(database.name.reactive$data)$id, server = TRUE)
    updateSelectizeInput(session, 'show_expt_id_sum', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
    updateSelectizeInput(session, 'show_expt_id_db_browser', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
    closeAlert(session, "savEdAlert")
    createAlert(session, "saveEditAlert", "savEdAlert", title = "Saving",
                content = "Saving...Success!", append = FALSE)  
    output$expt_id_list <- renderText({ 
      expt_id_msg <- paste("The currently selected database contains the following data sets from previous sessions:", paste(as.data.frame(DepLab:::list.expt.ids.w.organism(database.name.reactive$data))$expt_id, collapse="\n"), sep = "\n")
    })
    updateButton(session, "deleteButton", disabled = FALSE)
    updateButton(session, "EditButton", disabled = FALSE)
  })
  
  
 observeEvent(input$cancelEditsEbutton, {
    removeUI(
      selector = paste0('#', inserted[length(inserted)])
     # selector = '#placeholderEditButtons'
    )
   inserted <<- inserted[-length(inserted)]
   updateSelectizeInput(session, 'show_expt_id_db_browser', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE, selected = NULL)
   updateButton(session, "deleteButton", disabled = FALSE)
   updateButton(session, "EditButton", disabled = FALSE)
  })

 ## dynamic UI for DB editor
 

  observeEvent(input$file1$name, {
    closeAlert(session, "exampleAlert")
  })
  
  observeEvent(input$expt.id, {
    if(input$expt.id != ""){
      closeAlert(session, "exampleAlert")
    }
  })

  observeEvent(input$deleteButton, {
    if(input$show_expt_id_db_browser != ""){
      createAlert(session, "deleteAlert", "delAlert", title = "Deleting",
                  content = "Deleting experiment from database... This might take a while....", append = FALSE)
      DepLab:::delete.expt(database.name.reactive$data, input$show_expt_id_db_browser)
      
      updateSelectizeInput(session, 'show_expt_id', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
      updateSelectizeInput(session, 'show_expt_id_std', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
      updateSelectizeInput(session, 'show_trypsin_symbol', choices = DepLab:::list.std.gene.symbols(database.name.reactive$data)$id, server = TRUE)
      updateSelectizeInput(session, 'show_expt_id_sum', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
      updateSelectizeInput(session, 'show_expt_id_db_browser', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
      closeAlert(session, "delAlert")
      createAlert(session, "deleteAlert", "delAlert", title = "Deleting",
                  content = "Deleting...Success!", append = FALSE)  
      
      output$expt_id_list <- renderText({ 
        expt_id_msg <- paste("The currently selected database contains the following data sets from previous sessions:", paste(as.data.frame(DepLab:::list.expt.ids.w.organism(database.name.reactive$data))$expt_id, collapse="\n"), sep = "\n")
      })
    }
  })
  
  
  observeEvent(input$saveButton, {
    closeAlert(session, "exampleAlert")
    
    if(is.null(input$file1$name)){
      createAlert(session, "alert", "exampleAlert", title = "Oops",
                  content = "Select Maxquant data file before saving.", append = FALSE)
      return()
    } else if(input$expt.id == ""){
      createAlert(session, "alert", "exampleAlert", title = "Oops",
                  content = "Experimental ID required in order to save.", append = FALSE)
      return()
    }
    
    createAlert(session, "alert", "exampleAlert", title = "Saving",
                content = "Saving... This might take a while....", append = FALSE)
    if(file.info(database.name.reactive$data)$size == 0 || is.na(file.info(database.name.reactive$data)$size))
    {
      initialize.database(database.name.reactive$data, organism = "human", force = FALSE)
      initialize.database(database.name.reactive$data, organism = "yeast", force = FALSE)
    } 

    x <- read.MQ.data(normalizePath(paste(input$file1$datapath),winslash=.Platform$file.sep), input$expt.id, data.subset = "poi", input$organism)
    #x_genes <- as.data.frame(DepLab:::return.gene.symbols.from.id(database.name, x$id, input$organism))
    #x_genes$organism <- NULL
    #merge_x_genes <- merge(x, x_genes, by="id")
    #merge_x_genes$id <- NULL
    #x <- merge_x_genes[,c(6,1:5)]
    
    if(input$id_for_standard == "") {
      x.std <- read.MQ.data(normalizePath(paste(input$file1$datapath),winslash=.Platform$file.sep), input$expt.id, data.subset = "trypsin", organism = NULL)
    } else {
      std_list <- input$id_for_standard
      std_list <- unlist(strsplit(std_list,","))
      std_list <- gsub(" ", "", std_list, fixed = TRUE)
      x.std <- read.MQ.data(normalizePath(paste(input$file1$datapath),winslash=.Platform$file.sep), input$expt.id, data.subset = c(std_list), organism = NULL) 
    }
    
    df_readIn = try(add.expt.to.database(database.name.reactive$data, data.frame(expt_id = input$expt.id, organism = input$organism), NULL, x, x.std))

    if(class(df_readIn) == "try-error"){
      print(database.name.reactive$data)
      closeAlert(session, "exampleAlert")
      createAlert(session, "alert", "exampleAlert", title = "Oops",
                  content = "Experimental ID not unique!  Saving failed.", append = FALSE)
    } else {
      updateSelectizeInput(session, 'show_expt_id', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
      updateSelectizeInput(session, 'show_expt_id_std', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
      updateSelectizeInput(session, 'show_trypsin_symbol', choices = DepLab:::list.std.gene.symbols(database.name.reactive$data)$id, server = TRUE)
      updateSelectizeInput(session, 'show_expt_id_sum', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
      updateSelectizeInput(session, 'show_expt_id_db_browser', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, server = TRUE)
      closeAlert(session, "exampleAlert")
      createAlert(session, "alert", "exampleAlert", title = "Saving",
                  content = "Saving...Success!", append = FALSE)  
      database.name.reactive <- reactiveValues(data = database.name)

      output$expt_id_list <- renderText({ 
        expt_id_msg <- paste("The currently selected database contains the following data sets from previous sessions:", paste(as.data.frame(DepLab:::list.expt.ids.w.organism(database.name.reactive$data))$expt_id, collapse="\n"), sep = "\n")
      })
      
    }
  })
  
  # ===================
  # Plot tab:
  
  
  observeEvent(input$new.complex.name, ({
    txt <- input$new.complex.name
    disabled = NULL
    style = "default"
    icon = ""
    if(txt == "") {
      disabled = TRUE
      icon <- icon("ban")
    } else {
      disabled = FALSE
      icon = icon("check")
      
    }
    updateButton(session, "saveModalButton", disabled = disabled, style = style, icon = icon)
  }))  
  
  observeEvent(input$saveModalButton, {
    newDF <- data.frame("id"= input$new.complex.name, "gene symbol"=input$show_gene_symbol, "complex"=input$new.complex.name)
    # if(is.na(file.info(system.file("extdata","defined_complexes", "complexes_custom.txt", package = "DepLab"))$size)){
    #   cc.save <- paste(system.file("extdata","defined_complexes", package = "DepLab"), "complexes_custom.txt", sep = "/")
    # }else{
    # cc.save <-  system.file("extdata","defined_complexes", "complexes_custom.txt", package = "DepLab")
    # }
    write.table(newDF, custom.complexes.name.reactive$data, append = TRUE, row.names = FALSE, col.names = FALSE, na = "NA", quote=F, sep="\t")
    toggleModal(session, "save_as_complex_modal",close)
    updateTextInput(session, "new.complex.name", value = "")     
    custom_complexes <- reactiveValues(data = read.table(file=custom.complexes.name.reactive$data,sep="\t", stringsAsFactors=FALSE, header=TRUE))
    
    if(input$complex_source == "benschop"){
      cur_genes <- DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, "yeast", cur_len = cur_frac_table_length)$gene
      cur_inter <- intersect(cur_genes, benschop_complexes$data$gene_symbol)
      updateSelectizeInput(session, 'show_complex', choices = c(unique(benschop_complexes$data[match(cur_inter, benschop_complexes$data$gene_symbol),]$complex)))
    } else if (input$complex_source == "wodak"){
      cur_genes <- DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, "yeast", cur_len = cur_frac_table_length)$gene
      cur_inter <- intersect(cur_genes, wodak_complexes$data$gene_symbol)    
      updateSelectizeInput(session, 'show_complex', choices = c(unique(wodak_complexes$data[match(cur_inter, wodak_complexes$data$gene_symbol),]$complex)))
    } else if (input$complex_source == "custom") {
      updateSelectizeInput(session, 'show_complex', choices = c(unique(custom_complexes$data$complex)))
    } else if (input$complex_source == "corum") {
      cur_genes <- DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, "human", cur_len = cur_frac_table_length)$gene
      cur_inter <- intersect(cur_genes, corum_complexes$data$gene_symbol)
      updateSelectizeInput(session, 'show_complex', choices = c(unique(corum_complexes$data[match(cur_inter, corum_complexes$data$gene_symbol),]$complex)))
    }
    
  })
  
  
  ##
  values <- reactiveValues()
  proteasome_data <- reactiveValues(data=NULL)
  summary_data <- reactiveValues(data=NULL)
  standards_data <- reactiveValues(data=NULL)
  
  ### open palette selected upon button click
  observe({
    if (is.null(input$colorButton) || input$colorButton == 0){return()}
    values$pal <- choose_palette()
  })
  
  
  observe({
    if (is.null(input$colorButton2) || input$colorButton2 == 0){return()}
    values$pal2 <- choose_palette(n=50)
  })
  
  
  ### selectize complexes
  output$complexChoices <- renderUI({
    custom_complexes <- reactiveValues(data = read.table(file=custom.complexes.name.reactive$data,sep="\t", stringsAsFactors=FALSE, header=TRUE))
    
    if(input$complex_source == "benschop"){
      cur_genes <- DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, "yeast", cur_len = cur_frac_table_length)$gene
      cur_inter <- intersect(cur_genes, benschop_complexes$gene_symbol)
      selectizeInput('show_complex', '', choices = c(unique(benschop_complexes[match(cur_inter, benschop_complexes$gene_symbol),]$complex)) , multiple=TRUE) 
    } else if (input$complex_source == "wodak"){
      cur_genes <- DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, "yeast", cur_len = cur_frac_table_length)$gene
      cur_inter <- intersect(cur_genes, wodak_complexes$gene_symbol)
      selectizeInput('show_complex', '', choices = c(unique(wodak_complexes[match(cur_inter, wodak_complexes$gene_symbol),]$complex)) , multiple=TRUE) 
    } else  if (input$complex_source == "custom"){
      selectizeInput('show_complex', '', choices = c(unique(custom_complexes$data$complex)), multiple=TRUE) 
    } else if (input$complex_source == "corum") {
      cur_genes <- DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, "human", cur_len = cur_frac_table_length)$gene
      cur_inter <- intersect(cur_genes, corum_complexes$gene_symbol)
      selectizeInput('show_complex', '', choices = c(unique(corum_complexes[match(cur_inter, corum_complexes$gene_symbol),]$complex)) , multiple=TRUE) 
    }
  })
  
  ### zooming function
  ranges <- reactiveValues(x = NULL, y = NULL)
  
  observeEvent(input$proteasomePlot_dblclick, {
    brush <- input$proteasomePlot_brush
    if (!is.null(brush)) {
      ranges$x <- c(brush$xmin, brush$xmax)
      ranges$y <- c(brush$ymin, brush$ymax)
      
    } else {
      ranges$x <- NULL
      ranges$y <- NULL
    }
  })
  
  ranges_2 <- reactiveValues(x = NULL, y = NULL)
  observeEvent(input$proteasomeSummaryPlot_dblclick, {
    brush <- input$proteasomeSummaryPlot_brush
    if (!is.null(brush)) {
      ranges_2$x <- c(brush$xmin, brush$xmax)
      ranges_2$y <- c(brush$ymin, brush$ymax)
      
    } else {
      ranges_2$x <- NULL
      ranges_2$y <- NULL
    }
  })
  
  ###################################################### START TRYPSIN STUFF
  vars = reactiveValues(std_protein_counter = 0, std_pro_info_table = NULL)
  
  output$retrieve_protein_std_button <- renderUI({
    if(!is.null(input$show_expt_id_std)){
      if (is.null(input$show_trypsin_symbol)){
        return()
      } else {
        actionLink("retrieve_protein_std_info", label=retrieve_protein_std_button_label())
      }
    }
  })
  
  
  
  observeEvent( input$show_trypsin_symbol, {
    if(is.null(input$show_trypsin_symbol)){
      vars$std_protein_counter <-  0
    }
  }, ignoreNULL=FALSE)
  
  
  observeEvent(input$retrieve_protein_std_info, {
    if(!is.null(input$retrieve_protein_std_info)){
      input$retrieve_protein_std_info
      isolate({
        vars$std_protein_counter <-  vars$std_protein_counter + 1
      })
    }
  })
  
  retrieve_protein_std_button_label <- reactive({
    if(vars$std_protein_counter >= 1) label <- "Refresh UniProt info..."
    else label <- "Retrieve info from UniProt..."
  })
  
  
  observeEvent( input$show_trypsin_symbol, {
    if(is.null(input$show_trypsin_symbol)){
      df <- data.frame(NULL)
      vars$std_pro_info_table <- df
    }
  }, ignoreNULL=FALSE)
  
  output$std_prot_table = renderTable({
    vars$std_pro_info_table
  },  include.rownames=FALSE, sanitize.text.function = function(x) x)
  
  
  
  ranges_tryp <- reactiveValues(x = NULL, y = NULL)
  observeEvent(input$proteasomeTrypsinPlot_dblclick, {
    brush <- input$proteasomeTrypsinPlot_brush
    if (!is.null(brush)) {
      ranges_tryp$x <- c(brush$xmin, brush$xmax)
      ranges_tryp$y <- c(brush$ymin, brush$ymax)
      
    } else {
      ranges_tryp$x <- NULL
      ranges_tryp$y <- NULL
    }
  })
  
  observeEvent(input$show_expt_id_std, {
    updateSelectizeInput(session, 'show_trypsin_symbol', selected = c(DepLab:::list.selected.std.gene.symbols(database.name.reactive$data, input$show_expt_id_std)$id, input$show_trypsin_symbol), server = FALSE)
  })
  
  observeEvent( input$y_axis_choices_tryp, {
    if (input$y_axis_choices_tryp == "raw.intensity"){
      updateCheckboxGroupInput(session, "y_axis_log_tryp",  choices = c("log2", "normalize across fractions"))
    } else {
      updateCheckboxGroupInput(session, "y_axis_log_tryp",  choices = c("log2"))
    }
  })
  
  
  #    output$plot_trypsin <- renderPlotly({
  output$plot_trypsin <- renderPlot({
    # only render plot if gene symbol selected
    if(!is.null(input$show_expt_id_std)){
      if (is.null(input$show_trypsin_symbol)){
        return()
      } else {
        trypsin.dat <- as.data.frame(DepLab:::query.std.measurements.v2(database.name.reactive$data, c(input$show_expt_id_std), c(input$show_trypsin_symbol), c(input$y_axis_choices_tryp)))
        validate(
          need(nrow(trypsin.dat) > 0 , "UniProt ID(s) not found in any experiment.")
        )
        #  standards_data$data <- trypsin.dat
        if (is.null(values$pal_tryp)){
          color.palette=NULL
        } else {
          color.palette = values$pal_tryp
        }
        if (input$split_by_std == "none" ){
          split.by = NULL
        } else {
          split.by = input$split_by_std
        }
        if (input$split_by_std_col == "none" ){
          split.by.col = "."
        } else {
          split.by.col = input$split_by_std_col
        }
        if(any(grepl("fractions", c(input$y_axis_log_tryp)))) {
          trypsin.dat <- normalize_values(long.df = trypsin.dat,norm.type = "fraction", prot.identifier = "id")
        }
        if(any(grepl("log2", c(input$y_axis_log_tryp)))) {
          trypsin.dat$value <- log2( trypsin.dat$value +1)
          trypsin.dat$measurement <-  paste(trypsin.dat$measurement , "log2", sep= "_")
        }
        standards_data$data <- trypsin.dat
        plot_profile(trypsin.dat,  what = "id", color.palette=color.palette,split.by.col=split.by.col, y.lab=head(trypsin.dat$measurement, 1) ,split.by=split.by, color.by=input$color_by_choices_std, title=input$plot_tryp_title)  + coord_cartesian(xlim = ranges_tryp$x, ylim = ranges_tryp$y)
        #      #   p %>% ggplotly()
        #         p <- ggplotly(p)
        #         p %>% 
        #           layout(showlegend = T)
      } 
    }
  }, height=function() { session$clientData$output_plot_trypsin_width * 0.8 })
  
  
  observeEvent( input$retrieve_protein_std_info, {
    progress <- shiny::Progress$new()
    on.exit(progress$close())
    progress$set(message = "Retrieving info from UniProt....", value = 0)
    protDf <- read.table(text = unlist(lapply(as.list(isolate(unique(input$show_trypsin_symbol))), function(x) get_UniProt_info(x))), sep="")
    urls <- paste("http://www.uniprot.org/uniprot/", protDf$V1, sep="")
    refs <- paste0(paste0(paste0("<a href='",  urls, "' target='_blank'>"), "", protDf$V1), "", "</a>")
    protDf$V1 <- refs
    protDf$V5 <- paste(protDf$V5, "AA")
    protDf <- protDf[,c(-2, -6)]
    colnames(protDf) <- c("protein", "organism", "status", "size")
    vars$std_pro_info_table <- protDf[order(protDf$protein),]
  })
  
  
  observe({
    if (is.null(input$colorButton_tryp) || input$colorButton_tryp == 0){return()}
    values$pal_tryp <- choose_palette(n=3)
  })
  
  ###################################################### END TRYPSIN STUFF
  
  updateSelectizeInput(session, 'show_expt_id', choices = DepLab:::list.expt.ids.v2(database.name)$expt_id, server = TRUE)
  updateSelectizeInput(session, 'show_expt_id_sum', choices = DepLab:::list.expt.ids.v2(database.name)$expt_id, server = TRUE)
  updateSelectizeInput(session, 'show_expt_id_std', choices = DepLab:::list.expt.ids.v2(database.name)$expt_id, server = TRUE)
  updateSelectizeInput(session, 'show_trypsin_symbol', choices = DepLab:::list.std.gene.symbols(database.name)$id, server = TRUE)
  updateSelectizeInput(session, 'show_expt_id_db_browser', choices = DepLab:::list.expt.ids.v2(database.name)$expt_id, server = TRUE)
  

  current_org <- reactiveValues(counter=0 )
  
  observeEvent(input$show_expt_id, {
    if(is.null(input$show_expt_id)){
      output$current_organism <- renderText({paste("")})
      isolate(updateSelectizeInput(session, 'show_expt_id', choices = DepLab:::list.expt.ids.v2(database.name.reactive$data)$expt_id, selected=NULL, server = TRUE))
      isolate(updateSelectizeInput(session, 'show_gene_symbol', choices = NULL, selected=NULL, server = TRUE))
      current_org$counter = 0
    } 
  },ignoreNULL=FALSE)  
  
  observeEvent(input$show_expt_id, {
    if (current_org$counter == 0){
      current_org$counter =  1
      cur_sel = input$show_expt_id
      cur_sel_genes =  input$show_gene_symbol
      cur_org <- head(DepLab:::list.organism.by.expt.v2(database.name.reactive$data, input$show_expt_id)$organism, 1)
      output$current_organism <- renderText({paste("Data from:", cur_org)})

      isolate(updateSelectizeInput(session, 'show_expt_id', choices = DepLab:::list.expt.by.organism.v2(database.name.reactive$data, cur_org)$expt_id, selected=cur_sel, server = FALSE))
      
      isolate(updateSelectizeInput(session, 'show_gene_symbol', choices = DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, cur_org, cur_len = cur_frac_table_length)$gene, selected=cur_sel_genes, server = TRUE))
     # isolate(updateSelectizeInput(session, 'show_gene_symbol', choices =setNames( DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, cur_org, cur_len = cur_frac_table_length)$gene, paste("hey",  DepLab:::list.all.gene.symbols.v2(database.name.reactive$data, cur_org, cur_len = cur_frac_table_length)$gene, sep="-")), selected=cur_sel_genes, server = TRUE))
      
          }
  },ignoreNULL=TRUE)  

  
  
  
  
  output$plot_proteasome <- renderPlot({
    # only render plot if gene symbol selected
    if(!is.null(reac$show_expt_id)){
      if (is.null(reac$show_gene_symbol) & is.null(reac$show_complex)){
        return()
      } else {
        custom_complexes <- reactiveValues(data = read.table(file=custom.complexes.name.reactive$data,sep="\t", stringsAsFactors=FALSE, header=TRUE))
        if(input$complex_source == "benschop"){
          complex_select <- grep(  paste(paste(paste("^", make.names(reac$show_complex), sep=""), "$", sep=""), collapse="|") , make.names(benschop_complexes$complex))
          proteasome.dat <- as.data.frame(DepLab:::query.measurements.v2(database.name.reactive$data, reac$show_expt_id, c(reac$show_gene_symbol, benschop_complexes[complex_select,]$gene_symbol), input$y_axis_choices))
          complex_list <- benschop_complexes[complex_select,]
        } else if (input$complex_source == "wodak"){
          complex_select <- grep(  paste(paste(paste("^", make.names(reac$show_complex), sep=""), "$", sep=""), collapse="|") , make.names(wodak_complexes$complex))
          proteasome.dat <- as.data.frame(DepLab:::query.measurements.v2(database.name.reactive$data, reac$show_expt_id, c(reac$show_gene_symbol, wodak_complexes[complex_select,]$gene_symbol), input$y_axis_choices))
          complex_list <- wodak_complexes[complex_select,]
        } else if (input$complex_source == "corum"){
          complex_select <- grep(  paste(paste(paste("^", make.names(reac$show_complex), sep=""), "$", sep=""), collapse="|") , make.names(corum_complexes$complex))
          proteasome.dat <- as.data.frame(DepLab:::query.measurements.v2(database.name.reactive$data, reac$show_expt_id, c(reac$show_gene_symbol, corum_complexes[complex_select,]$gene_symbol), input$y_axis_choices))
          complex_list <- corum_complexes[complex_select,]
        } else {
          complex_select <- grep(  paste(paste(paste("^", make.names(reac$show_complex), sep=""), "$", sep=""), collapse="|") , make.names(custom_complexes$data$complex))
          proteasome.dat <- as.data.frame(DepLab:::query.measurements.v2(database.name.reactive$data, reac$show_expt_id, c(reac$show_gene_symbol, custom_complexes$data[complex_select,]$gene_symbol), input$y_axis_choices))
          complex_list <- custom_complexes$data[complex_select,]
        }
        validate(
          need(nrow(proteasome.dat) > 0 , "Gene(s) or complex(es) not found in any experiment.")
        )
        if (is.null(values$pal)){
          color.palette=NULL
        } else {
          color.palette = values$pal
        }
        if (input$split_by == "none" ){
          split.by = NULL
        } else {
          split.by = input$split_by
        }
        if (input$split_by_col == "none" ){
          split.by.col = "."
        } else {
          split.by.col = input$split_by_col
        }
        if (input$split_by == "complex" || input$split_by_col == "complex" || input$color_by_choices == "complex" || nrow(complex_list) > 0 ){
          validate(
            need(nrow(complex_list) > 0 , "Can't split by complex unless one or more complexes is selected. ")
          )
          proteasome.dat <- merge(proteasome.dat, complex_list, by=c("gene_symbol"), all=TRUE)
          proteasome.dat <- proteasome.dat[!is.na(proteasome.dat$expt_id),] 
          proteasome.dat$id.y <- NULL
          colnames(proteasome.dat) <- c("gene_symbol", "fraction", "value", "measurement", "expt_id", "organism","id", "complex")
        }
        if(input$pointShape == "complex"){
          validate(
            need(nrow(complex_list) > 0 , "Can't assign point shape to complex unless one or more complexes is selected. ")
          )
        }
        
        if(input$lineType == "complex"){
          validate(
            need(nrow(complex_list) > 0 , "Can't assign line type to complex unless one or more complexes is selected. ")
          )
        }
        if(any(grepl("spike", c(input$y_axis_log)))) {
          selected_ctrl_names <- paste("input$radio_var", seq(1,length(reac$show_expt_id)), sep="")
          selected_ctrl_list <- NULL
          for (i in 1:length(selected_ctrl_names) ) {
            selected_ctrl_list <- c(selected_ctrl_list, eval(parse(text=selected_ctrl_names[i])))
          }
          
        #  df <- data.frame(exps = reac$show_expt_id, stds= selected_ctrl_list)
         # print(df)
          
        #  prot.stds <- data.frame()
       #   for (i in 1:nrow(df)){
      #      print(i)
     #       prot.stds <- rbind(prot.stds, as.data.frame(DepLab:::query.std.measurements(database.name.reactive$data, df[i,1], df[i,2], input$y_axis_choices)))
    #      }

          prot.stds <- as.data.frame(DepLab:::query.std.measurements.v2(database.name.reactive$data, reac$show_expt_id, selected_ctrl_list, input$y_axis_choices) )

        #  prot.stds <- DepLab:::query.std.measurements(database.name.reactive$data, reac$show_expt_id, selected_ctrl_list, input$y_axis_choices) 
          proteasome.dat <- normalize_values(long.df = proteasome.dat, norm.type = "spike-in", std.df = prot.stds)
        }
        if(any(grepl("fractions", c(input$y_axis_log)))) {
          proteasome.dat <- normalize_values(long.df = proteasome.dat,norm.type = "fraction", prot.identifier = "gene_symbol")
        }
        
        if(any(grepl("log2", c(input$y_axis_log)))) {
          proteasome.dat$value <- log2( proteasome.dat$value +1)
          proteasome.dat$measurement <-  paste(proteasome.dat$measurement, "log2", sep= "_")
        }
        if(any(grepl("smooth", c(input$y_axis_log)))) {
          proteasome.dat <- proteasome.dat[with(proteasome.dat, order(expt_id, gene_symbol, fraction)), ] 
          ps <- ddply(proteasome.dat, .(expt_id, gene_symbol), function(x) data.frame(xspline(x[,2:3], shape=-0.5, draw=F)) )
          line.smooth <- "YES"
        } else {
          line.smooth <- NULL
        }
        proteasome_data$data <- proteasome.dat
#        proteasome.dat <- proteasome.dat[with(proteasome.dat, order(expt_id, gene_symbol, fraction)), ] 
       # ps <- data.frame(xspline(proteasome.dat[,2:3], shape=-0.5, lwd=2, draw=F))

        
        # ddply(proteasome.dat, .(expt_id, gene_symbol), function(x) data.frame(xspline(x[,2:3], shape=-0.5, lwd=2, draw=F)) )
        plot_profile(proteasome.dat, ps=ps,  line.smooth=line.smooth, color.palette=color.palette, y.lab = head(proteasome.dat$measurement, 1), split.by=split.by , split.by.col=split.by.col, color.by=input$color_by_choices, line.type=input$lineType, line.size=as.numeric(input$lineSize), point.shape=input$pointShape, point.size=as.numeric(input$pointSize), title=input$plot_title)  + coord_cartesian(xlim = ranges$x, ylim = ranges$y)
      }
    }
  }, height=function() { session$clientData$output_plot_proteasome_width * 0.8 })
  
  
  observeEvent( input$show_gene_symbol, {
    if(is.null(input$show_gene_symbol) & is.null(input$show_complex)){
      df <- data.frame(NULL)
      vars$pro_info_table <- df
    }
  }, ignoreNULL=FALSE)
  
  output$prot_table = renderTable({
    vars$pro_info_table
  },  include.rownames=FALSE, sanitize.text.function = function(x) x)
  
  observeEvent( input$retrieve_protein_info, {
    progress <- shiny::Progress$new()
    on.exit(progress$close())
    progress$set(message = "Retrieving info from UniProt....", value = 0)
    dfProt <- isolate(proteasome_data$data[,c(1,6,7)])
    dfProt <- unique(dfProt)
    if(dfProt$organism == "yeast") {
      unprot_df <- readLines("./yeast.txt")
      unprot_df <- gsub("; ", "", unprot_df) 
      unprot_df <- gsub("\\s+", " ", str_trim(unprot_df))
      unprot_df <- strsplit(unprot_df, " ")
      indx <- sapply(unprot_df, length)
      res <- as.data.frame(do.call(rbind,lapply(unprot_df, `length<-`,max(indx))))
      findUniProt <- subset(res, V2 %in% c(dfProt$id))[,c(3,2)]
      dfProt <- merge(dfProt,findUniProt, by.x="id", by.y="V2")
      colnames(dfProt) <- c("id", "gene_symbol","organism", "protein")
      protDf <- read.table(text = unlist(lapply(as.list(unique(findUniProt$V3)), function(x) get_UniProt_info(x))), sep="")
      protDf <- merge(dfProt, protDf, by.x="protein", by.y="V1")
      urls <- paste("http://www.uniprot.org/uniprot/", protDf$protein, sep="")
      refs <- paste0(paste0(paste0("<a href='",  urls, "' target='_blank'>"), "", protDf$protein), "", "</a>")
      protDf$protein <- refs
      protDf$V5 <- paste(protDf$V5, "AA")
      protDf <- protDf[,c(-4,-5,-9)]
      protDf <- protDf[,c(3,2,1,4,5,6)]
      colnames(protDf) <- c("gene", "id", "protein", "organism", "status", "size")
      vars$pro_info_table <- protDf[order(protDf$gene),]
    } else if(dfProt$organism == "human"){
      protDf <- read.table(text = unlist(lapply(as.list(isolate(unique(dfProt$id))), function(x) get_UniProt_info(x))), sep="")
      dfProt <- merge(dfProt,protDf, by.x="id", by.y="V1")
      urls <- paste("http://www.uniprot.org/uniprot/", protDf$V1, sep="")
      refs <- paste0(paste0(paste0("<a href='",  urls, "' target='_blank'>"), "", protDf$V1), "", "</a>")
      dfProt$id <- refs
      dfProt$V5 <- paste(dfProt$V5, "AA")
      dfProt <- dfProt[,c(-3, -4, -8)]
      colnames(dfProt) <- c("protein", "gene", "organism", "status", "size")
      dfProt <- dfProt[,c(2,1,3,4,5)]
      vars$pro_info_table <- dfProt[order(dfProt$gene),]
    }
  })
  
  
  output$plot_summary <- renderPlot({
    if(!is.null(reacSum$show_expt_id_sum)){
   #   if(isolate(reacSum$redrawSum)){
        if (is.null(values$pal2)){
          color.palette=NULL
        } else {
          color.palette = values$pal2
        }
        if (input$split_by_summary == "none" ){
          split.by = NULL
        } else {
          split.by = input$split_by_summary
        } 
        long.df <- as.data.frame(DepLab:::query.measurements.by.expt.v2(database.name.reactive$data, reacSum$show_expt_id_sum, input$y_axis_choices_sum))#[,c(2,3,5)]
        
        if(any(grepl("log2", c(input$y_axis_log_2)))) {
          long.df$value <- log2( long.df$value +1)
       #   long.df$measurement <-  paste(long.df$measurement , "log2", sep= "_")
        }
        
        summary_data$data <- long.df
        plot_cumulativeValues(long.df = long.df, split.by = split.by, color.palette=color.palette, y.lab = input$y_axis_choices_sum ,title=input$plot_summary_title, x.interval=input$summary_x_interval) + coord_cartesian(xlim = ranges_2$x, ylim = ranges_2$y)
      }
   # }
  })
  
  
  # ===================
  # Table tab: Render searchable/subsettable tables
  output$proteasomedata <- renderDataTable({
    validate(
      need(nrow(proteasome_data$data) > 0 , "Select some data on corresponding plot page.")
    )
    proteasome_data$data 
  })
  
  output$summarydata <- renderDataTable({
    validate(
      need(nrow(summary_data$data ) > 0 , "Select some data on corresponding plot page.")
    )
    summary_data$data 
  })

#   
  output$save_sum_table <- downloadHandler(
    filename = function() {
      paste("summary", "csv", sep = ".")
    },
    content = function(file) {
   write.csv(summary_data$data , file, col.names=TRUE, row.names=FALSE, quote=FALSE)
    }
  )
  
#  shinyFileSave(input, 'save_sum_table',  roots=volumes, session=session)
#  saveFileName <- renderPrint({parseSavePath(volumes, input$save_sum_table)})
#  observeEvent( input$save_sum_table, {
#    savePath <- strsplit(saveFileName(), " csv ", fixed = FALSE, perl = FALSE, useBytes = FALSE)[[1]][2]
#    write.csv(summary_data$data , savePath, col.names=TRUE, row.names=FALSE, quote=FALSE)
#  })
  
  output$save_indiv_table <- downloadHandler(
    filename = function() {
      paste("individual_profile", "csv", sep = ".")
    },
    content = function(file) {
      write.csv(proteasome_data$data , file, col.names=TRUE, row.names=FALSE, quote=FALSE)
    }
  )
  

#  shinyFileSave(input, 'save_indiv_table', roots=volumes, session=session)
#  saveFileName <- renderPrint({parseSavePath(volumes, input$save_indiv_table)})
#  observeEvent( input$save_indiv_table, {
#    savePath <- strsplit(saveFileName(), " csv ", fixed = FALSE, perl = FALSE, useBytes = FALSE)[[1]][2]
#    write.csv(proteasome_data$data, savePath, col.names=TRUE, row.names=FALSE, quote=FALSE)
#  })
  
  output$save_std_table <- downloadHandler(
    filename = function() {
      paste("standards", "csv", sep = ".")
    },
    content = function(file) {
      write.csv(standards_data$data , file, col.names=TRUE, row.names=FALSE, quote=FALSE)
    }
  )
#  shinyFileSave(input, 'save_std_table', roots=volumes, session=session)
#  saveFileName <- renderPrint({parseSavePath(volumes, input$save_std_table)})
#  observeEvent( input$save_std_table, {
#    savePath <- strsplit(saveFileName(), " csv ", fixed = FALSE, perl = FALSE, useBytes = FALSE)[[1]][2]
#    write.csv(standards_data$data, savePath, col.names=TRUE, row.names=FALSE, quote=FALSE)
#  })
  
  output$standardsedata <- renderDataTable({
    validate(need(
      nrow(standards_data$data) > 0 , "Select some data on corresponding plot page."
    ))
    standards_data$data
  })


})
