library('testthat')
 
#library('DepLab')
#devtools::load_all(pkg = "~/Documents/Projects/2015-11_NoahDephoure_Proteomics/dephourelab/DepLab/"))

test_check('DepLab') 
#test_dir('tests', reporter = 'Summary')
