## ----echo = FALSE--------------------------------------------------------
library(knitr)
opts_chunk$set(cache = FALSE, echo = TRUE, message = FALSE, warning = FALSE, eval = FALSE)

## ----yeastRoutine--------------------------------------------------------
#  devtools::load_all()
#  
#  mq1 <- reading_MQ(system.file("extdata","test_data", "proteinGroups_100mM_new.txt", package = "DepLab"))
#  mqclean <- cleaning_MQ(mq1, remove.contaminants = TRUE, remove.decoys = TRUE, poi = "yeast")
#  ids.list <- extract_proteinID(mqclean$Protein.IDs, routine = "yeast")
#  mq.raw.intensity <- MQ_to_longFormat(mqclean, y = "raw.intensity", ids.list)
#  head(mq.raw.intensity)

## ----spikeInRoutine------------------------------------------------------
#  std <- cleaning_MQ(mq.df = mq1, remove.contaminants = FALSE, remove.decoys = TRUE,
#                     poi = NULL, spikeIn = c("P07477", "Q0140","YAL003W"))
#  stdid <- extract_proteinID(std$Protein.IDs, regex = c(".*(P07477|Q0140|YAL003W).*", "\\1"), label = "id", routine = NULL)
#  std.raw.intensity <- MQ_to_longFormat(std, y = "raw.intensity", stdid)

## ----humanRoutine--------------------------------------------------------
#  devtools::load_all()
#  
#  mq.h <- reading_MQ(system.file("extdata","test_data", "proteinGroups_human.txt", package = "DepLab"))
#  mq.h.clean <- cleaning_MQ(mq.h, remove.contaminants = TRUE, remove.decoys = TRUE, poi = "human")
#  ids.list <- extract_proteinID(mq.h.clean$Protein.IDs, routine = "human")
#  mq.h.raw.intensity <- MQ_to_longFormat(mq.h.clean, y = "raw.intensity", ids.list)
#  head(mq.h.raw.intensity)

## ----newMQformat---------------------------------------------------------
#  mq.h.new <- reading_MQ("~/Documents/Projects/2015-11_NoahDephoure_Proteomics/fromNoah_2016-03/proteinGroups_MCF10A_dounce_TSK_new.txt")
#  mq.h.new.clean <- cleaning_MQ(mq.h.new, remove.contaminants = TRUE, remove.decoys = TRUE, poi = "human")
#  ids.h.new <- extract_proteinID(mq.h.new.clean$Protein.IDs, routine = "human")
#  mq.h.raw.intensity <- MQ_to_longFormat(mq.h.new.clean, y= "raw.intensity", ids.h.new)
#  
#  std.h.old <- cleaning_MQ(mq.df = mq.h, remove.contaminants = FALSE, remove.decoys = TRUE,
#                     poi = NULL, spikeIn = c("P00761","P07477"))
#  std.h.new <- cleaning_MQ(mq.df = mq.h.new, remove.contaminants = FALSE, remove.decoys = TRUE,
#                     poi = NULL, spikeIn = c("P00761","P07477"))
#  std.y <- cleaning_MQ(mq.df = mq1, remove.contaminants = FALSE, remove.decoys = TRUE,
#                     poi = NULL, spikeIn = c("P00761","P07477"))
#  
#  std.new <- cleaning_MQ(mq.h.new, remove.contaminants = FALSE, remove.decoys = TRUE, poi = NULL, spikeIn = "P07477")
#  stdinf.new <- extract_proteinID(std.new, regex = c(".*(P07477).*", "\\1"), label = "id", routine = NULL)
#  std.raw.intensity <- MQ_to_longFormat(std.new, y = "raw.intensity",stdinf.new)
#  
#  

## ----checkDB-------------------------------------------------------------
#  database.name <- system.file("extdata", "proteomics.db", package = "DepLab")
#  filename <- system.file("extdata","test_data", "proteinGroups_100mM_new.txt", package = "DepLab")
#  expt.id <- "pg_100mM"
#  
#  ## create the database, and completely overwrite if it already exists (useful for debugging!)
#  initialize.database(database.name, organism.name = "yeast", force = TRUE)
#  
#  ## read the data in and turn it into a format suitable for the data base
#  x <- read.MQ.data(filename, expt.id, organism = "yeast")
#  head(x)
#  
#  ## testing the manual input of protein IDs ( aka standards aka spike-ins)
#  y <- read.MQ.data(filename, expt.id, organism = NULL, data.subset = c("P07477", "Q0140","YAL003W"))
#  head(y)
#  
#  ## add the data to the db
#  add.expt.to.database(database.name, data.frame(expt_id = expt.id, organism = "yeast"), NULL, x, y)

## ----checkNorm-----------------------------------------------------------
#  mq.y.1 <- read.MQ.data(filename = system.file("extdata", "test_data", "proteinGroups_100mM_new.txt", package = "DepLab"), expt.id = "100mM", data.subset = "poi", organism = "yeast")
#  mq.y.3 <- read.MQ.data(filename = system.file("extdata", "test_data", "proteinGroups_300mM_new.txt", package = "DepLab"), expt.id = "300mM", data.subset = "poi", organism = "yeast")
#  mqcombi <- rbind(mq.y.1, mq.y.3)
#  fraction.norm <- normalize_values(long.df = subset(mqcombi, measurement == "raw.intensity"),
#                                    norm.type = "fraction", prot.identifier = "id")

## ----plotting------------------------------------------------------------
#  mqcombi.plot <- subset(mqcombi, measurement == "raw.intensity" & id %in% c("YAL003W", "YAL005C"))
#  P <- plot_profile(mqcombi.plot, what = "id", color.by = "id", split.by = "expt_id")
#  
#  # adding marker for molecular weight
#  mwmark <- data.frame(expt_id = c("100mM","300mM"), MWmarker = c(15,25))
#  P + geom_vline(data = mwmark, aes(xintercept = MWmarker), linetype="dashed")

## ----buildBundle---------------------------------------------------------
#  # example path
#  ##setwd("/Users/frd2007/Documents/Projects/2015-11_NoahDephoure_Proteomics/dephourelab/DepLab")
#  devtools::load_all()
#  # update date and version number in DESCRIPTION
#  devtools::document()
#  devtools::build(path = "~/Dropbox/github/randomScripts/ABC/")

## ----installBundledPackage-----------------------------------------------
#  setwd("~/Desktop")
#  
#  # download package bundle and install it
#  devtools::install_url(url = "http://chagall.med.cornell.edu/deplab-pcp/DepLab_0.0.0.9000.tar.gz")
#  
#  # attach the package to your current workspace
#  library(DepLab)
#  
#  # test if app runs
#  runPCP()

