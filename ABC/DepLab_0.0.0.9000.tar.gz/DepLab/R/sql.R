#library(RSQLite)
#library(dplyr)


#' Pre-populate info table with all the known yeast genes from SGD
#'
#' Initiate data base with gene symbols and IDs
#' 
#' @param infile path to organism-specific table
#' 
#' @details
#' \bold{Yeast data} derived from
#' http://downloads.yeastgenome.org/curation/chromosomal_feature/SGD_features.tab
#' and generated using:
#' $ awk -F "t" {if ($2 == "ORF") {if ($5 != "") {n = $5} else {n = $4}; printf "%s\t%s\t%s\n", $1, $4, n} } SGD_features.tab
#' 
#' \bold{Human} info downloaded from uniprot.org with the following search:
#' organism:human AND organism:"Homo sapiens (Human) [9606]" 
#' AND proteome:up000005640
#' 
#' cut -f 1-2 *tab | sed "1d" > human_uniprot.entry.name
#' @export
read.id.info <- function(organism) {
  id.info <- read.table( system.file("extdata", paste(organism, "id.txt", sep="."), package = "DepLab"),
                         header = FALSE, stringsAsFactors = FALSE,
                         col.names = c("id", "gene_symbol"))
  id.info$organism <- organism
  return(id.info)
}


#' Reading MaxQuant data
#' 
#' @description 
#' This reads in the MaxQuant output, retrieves the proteins of interest and
#' generates a long data.frame for _all types of measurement_ that are available
#' across all fractions.
#' 
#' @param filename path to MaxQuant output (proteinGroups.txt)
#' @param expt.id unique identifier for the experiment to be read in
#' @param data.subset a string specifying what kind of data should be retrieved,
#' one of:
#' \itemize{
#' \item "poi": extract information for proteins of interest -- if you choose
#' this option, make sure to indicate the organism!
#' \item "trypsin": extract information for trypsin
#' \item a specific UniProt ID or yeast ORF, e.g. "P00761"
#' }
#' @param organism This determines how the proteins of interest should be
#' retrieved, i.e., indicate either 'human' or 'yeast', or NULL if data.subset 
#' is not 'poi'.
#' 
#' @return A long data.frame where each row corresponds to a single protein,
#' and one type of measured value per fraction.
#' 
#' @seealso @seealso \code{\link{reading_MQ}}, \code{\link{cleaning_MQ}},
#' \code{\link{info_from_fastaHeader}}
#' @export
read.MQ.data <- function(filename, organism = NULL, expt.id, data.subset = "poi") {

  #### 1. read MaxQuant output
  mq <- reading_MQ(filename)
  
  #### 2. subset the MaxQuant output and get info from FASTA header, 
  ####    either for proteins of interest for a given organism
  ####    or by specifying specific IDs, e.g., for the spike-in control(s)
  
  if (all(data.subset == "poi")) {# --> a) proteins of interest based on a defined organism
    
    if(is.null(organism))(stop("If you want to retrieve proteins of interest, you must specify the organism, e.g., 'yeast'."))
    
    mq.clean <- cleaning_MQ(mq, remove.contaminants = TRUE, 
                              remove.decoys = TRUE, poi = organism)
    mq.ids <- info_from_fastaHeader(mq.clean$Fasta.headers, routine = organism)
    
  }else{# --> b) lists of manually defined proteins (or "trypsin")
      if(!is.null(organism))stop(paste("The organism will be ignored for retrieving data for", data.subset))
      
      mq.clean <- cleaning_MQ(mq, remove.contaminants = FALSE,
                              remove.decoys = TRUE, spikeIn = data.subset)
      
      if(all(data.subset == "trypsin")){
        mq.ids <- info_from_fastaHeader(mq.clean$Fasta.headers, routine = "trypsin")
      }else{
        if(length(data.subset > 1)){
          uniprot.regex <- c( paste(".*(", paste(data.subset, collapse = "|"), ").*", sep = ""), "\\1")
        }else{
          uniprot.regex <- c(paste(".*(", data.subset, ").*", sep = ""), "\\1")
        }
        mq.ids <- info_from_fastaHeader(mq.clean$Fasta.headers, 
                                        regex = uniprot.regex,
                                        label = "uniprot", 
                                        routine = NULL)
      }
  }

  #### 3. generate skinny data.frames by iterating through the available
  ####    types of data
  types <- list("peptides.count", "unique.peptides.only", "razor.and.unique.peptides", 
                "sequence.coverage", "raw.intensity", "LFQ.intensity", "MS.MS.count")
  
  mq.data <- lapply(types, function(x) MQ_to_longFormat(mq.clean, y = x, mq.ids))
  mq.data <- do.call(rbind, mq.data)
  
  ##### 4. make format suitable for data base entry
  mq.data$expt_id <- as.factor(expt.id)
  mq.data$measurement <- as.factor(mq.data$measurement)
  
  if(all(data.subset == "poi")){
    mq.data$organism <- organism
    mq.data$id <- NULL
  }else{
    colnames(mq.data)[colnames(mq.data) == "uniprot"] <- "id"
    mq.data$id_type <- as.factor("SWISS-PROT")
    mq.data <- mq.data[c("id", "id_type", "fraction", "value", "measurement", "expt_id")]
  }
  
  return(mq.data)
}

#' Create the data base
#' 
#' @export
initialize.database <- function(database.name, organism.name, force = FALSE) {
  db <- dbConnect(SQLite(), dbname=database.name)
  tables <- dbListTables(db)
  len_tables <- length(tables)
#   if (!force) { # ensure that tables don't already exist (don't want to accidentally wipe an entire database!)
#     tables <- dbListTables(db)
#     if (length(tables) != 0) {
#       stop("Database is not empty!")
#     }
#   }
  # Populate sgd_info table with all known yeast proteins
  # If we are forcing initialization, we overwrite any previously existing data

  # Create table schemas for expt_info, prot_data and frac_data tables
  if (force) {
    dbGetQuery(conn = db, "drop table if exists id_info")
    dbGetQuery(conn = db, "drop table if exists expt_info")
    dbGetQuery(conn = db, "drop table if exists prot_data")
    dbGetQuery(conn = db, "drop table if exists frac_data")
    dbGetQuery(conn = db, "drop table if exists std_data")
  }
  dbWriteTable(conn = db, name = "id_info",
               value = read.id.info(organism = organism.name),
               row.names = FALSE, append = TRUE, overwrite=FALSE)
  if (len_tables == 0) {
    expt.info.sql <- "create table expt_info (expt_id TEXT NOT NULL, 
                                              organism TEXT NOT NULL,
                                              PRIMARY KEY (expt_id, organism))"
    dbGetQuery(conn = db, expt.info.sql)
    frac.data.sql <- "create table frac_data (gene_symbol TEXT NOT NULL, 
                                           fraction INTEGER NOT NULL,
                                           value REAL NOT NULL,
                                           measurement TEXT NOT NULL,
                                           expt_id TEXT NOT NULL,
                                           organism TEXT NOT NULL,
                                           PRIMARY KEY (organism, expt_id, gene_symbol, measurement, fraction))"
    dbGetQuery(conn = db, gsub("  ", "", frac.data.sql))
    std.data.sql <- "create table std_data (id TEXT NOT NULL, 
                                          id_type TEXT NOT NULL,
                                          fraction INTEGER NOT NULL,
                                          value REAL NOT NULL,
                                          measurement TEXT NOT NULL,
                                          expt_id TEXT NOT NULL,
                                          PRIMARY KEY (expt_id, id, measurement, fraction))"
    dbGetQuery(conn = db, gsub("  ", "", std.data.sql))
  }
  dbDisconnect(db)
}

#' Add uploaded data to the existing data base
#' 
#' Adds data from a new MaxQuant output file to the data base.
#' 
#' @param database.name path to the existing data base, e.g., proteomics.dv
#' @param expt.info metadata associated with the experiment
#' (one row per expt) (still to come)
#' @param prot.data data per protein per expt 
#' (incl all columns that are not frac.data)
#' @param frac.data data per protein per fraction per expt (here, mq.data)
#' @param std.data data per standard per fraction per expt (from mq.data)
#' @export
add.expt.to.database <- function(database.name, expt.info, prot.data, frac.data, std.data) {
  db <- dbConnect(SQLite(), dbname = database.name)
  dbWriteTable(conn = db, name = "expt_info", value = expt.info, row.names = FALSE, append = TRUE)
  #dbWriteTable(conn = db, name = "prot_data", value = prot.data, row.names = FALSE, append = TRUE)
  dbWriteTable(conn = db, name = "frac_data", value = frac.data, row.names = FALSE, append = TRUE)
  dbWriteTable(conn = db, name = "std_data", value = std.data, row.names = FALSE, append = TRUE)
  dbDisconnect(db)
}

# Query the frac_data table, filtering by expt_id, gene_symbol and measurement
query.measurements <- function(database.name, expt.ids, gene.symbols, measurement.type) {
  conn <- src_sqlite(path = database.name)
  dq <-  inner_join(tbl(conn, "frac_data"),
                   tbl(conn, "id_info"),
                   by = "gene_symbol") %>% 
    filter(expt_id %in% c('foo_dummy', expt.ids)) %>% # [bug in dplyr] hack to allow expt.ids vector to only contain one element
    filter(gene_symbol %in% c('foo_dummy', gene.symbols)) %>% 
    filter(measurement == measurement.type)
  # dq$query shows the SQL query that will be sent to the database
  dq %>% collect()
}

# Query the frac_data table, filtering by expt_id, and measurement
query.measurements.by.expt <- function(database.name, expt.ids, measurement.type) {
  conn <- src_sqlite(path = database.name)
  dq <- tbl(conn, "frac_data") %>% 
    filter(expt_id %in% c('foo_dummy', expt.ids)) %>% # [bug in dplyr] hack to allow expt.ids vector to only contain one element
    filter(measurement == measurement.type)
  # dq$query shows the SQL query that will be sent to the database
  dq %>% collect()
}

# Query the std_data table, filtering by expt_id, gene_symbol and measurement
query.std.measurements <- function(database.name, expt.ids, std.ids, measurement.type) {
  conn <- src_sqlite(path = database.name)
  dq <- tbl(conn, "std_data") %>% 
    filter(expt_id %in% c('foo_dummy', expt.ids)) %>%
    filter(id %in% c('foo_dummy', std.ids)) %>% 
    filter(measurement == measurement.type)
  # dq$query shows the SQL query that will be sent to the database
  dq %>% collect()
}

#' Query the std_data table
#' 
#' Query the data for the spike-in while filtering by expt_id and measurement
query.std.measurements.by.expt <- function(database.name, expt.ids, measurement.type) {
  conn <- src_sqlite(path = database.name)
  dq <- tbl(conn, "std_data") %>% 
    filter(expt_id %in% c('foo_dummy', expt.ids)) %>%
    filter(measurement == measurement.type)
  # dq$query shows the SQL query that will be sent to the database
  dq %>% collect()
}

#' @export
list.expt.ids <- function(database.name) {
  conn <- src_sqlite(path = database.name)
  dq <- conn %>% 
    tbl("expt_info") %>% 
    select(expt_id)
  dq %>% collect() %>% distinct()
}

#' @export
list.expt.ids.w.organism <- function(database.name) {
  conn <- src_sqlite(path = database.name)
  dq <- conn %>% 
    tbl("expt_info") %>% 
    select(expt_id, organism)
  dq %>% collect() %>% distinct()
}


# 
list.organism.by.expt <- function(database.name, expt.ids) {
  conn <- src_sqlite(path = database.name)
  dq <- tbl(conn, "expt_info") %>% 
    filter(expt_id %in% c('foo_dummy', expt.ids)) # [bug in dplyr] hack to allow expt.ids vector to only contain one element
  dq %>% collect()
}

# 
list.expt.by.organism <- function(database.name, organism.name) {
  conn <- src_sqlite(path = database.name)
  dq <- tbl(conn, "expt_info") %>% 
    filter(organism %in% c('foo_dummy', organism.name)) # [bug in dplyr] hack to allow expt.ids vector to only contain one element
  dq %>% collect()
}

#' @export
list.measurement.types <- function(database.name) {
  conn <- src_sqlite(path = database.name)
  dq <- conn %>% 
    tbl("frac_data") %>%
    select(measurement)
  dq %>% collect() %>% distinct()
}

#' @export
list.all.gene.symbols <- function(database.name, organism.name) {
  conn <- src_sqlite(path = database.name)
  dq <- conn %>% 
    tbl("frac_data") %>%
    filter(organism == organism.name) %>%
    select(gene_symbol)
  dq %>% collect() %>% distinct()
}

#' @export
list.all.gene.symbols.in.id.table <- function(database.name, organism.name) {
  conn <- src_sqlite(path = database.name)
  dq <- conn %>% 
    tbl("id_info") %>%
    filter(organism == organism.name) %>%
    select(gene_symbol)
  dq %>% collect() %>% distinct()
}

#' @export
list.std.gene.symbols <- function(database.name) {
  conn <- src_sqlite(path = database.name)
  dq <- conn %>% 
    tbl("std_data") %>%
    select(id)
  dq %>% collect() %>% distinct()
}

#' @export
list.selected.std.gene.symbols <- function(database.name, expt.ids) {
  conn <- src_sqlite(path = database.name)
  dq <- conn %>% 
    tbl("std_data") %>%
    filter(expt_id %in% c('foo_dummy', expt.ids)) %>%
    select(id)
  dq %>% collect() %>% distinct()
}

#' @export
list.selected.gene.symbols <- function(database.name, expt.ids) {
  conn <- src_sqlite(path = database.name)
  dq <- conn %>% 
    tbl("frac_data") %>% 
    filter(expt_id %in% c('foo_dummy', expt.ids)) %>%
    select(gene_symbol)
  dq %>% collect() %>% distinct()
}
