## ----echo = FALSE--------------------------------------------------------
library(knitr)
opts_chunk$set(cache = FALSE, echo = TRUE, message = FALSE, warning = FALSE, eval = FALSE)

## ----yeastRoutine--------------------------------------------------------
#  devtools::load_all()
#  
#  mq1 <- reading_MQ(system.file("extdata", "proteinGroups_100mM_new.txt", package = "DepLab"))
#  mqclean <- cleaning_MQ(mq1, remove.contaminants = TRUE, remove.decoys = TRUE, poi = "yeast")
#  ids.list <- info_from_fastaHeader(mqclean$Fasta.headers, routine = "yeast")
#  mq.raw.intensity <- MQ_to_longFormat(mqclean, y = "raw.intensity", ids.list)
#  head(mq.raw.intensity)

## ----spikeInRoutine------------------------------------------------------
#  std <- cleaning_MQ(mq.df = mq1, remove.contaminants = FALSE, remove.decoys = TRUE,
#                     poi = NULL, spikeIn = c("P07477", "Q0140","YAL003W"))
#  stdid <- info_from_fastaHeader(fasta.info = std$Fasta.headers,regex = c(".*(P07477|Q0140|YAL003W).*", "\\1"), label = "uniprot",routine = NULL)
#  std.raw.intensity <- MQ_to_longFormat(std, y = "raw.intensity", stdid)

## ----humanRoutine--------------------------------------------------------
#  devtools::load_all()
#  
#  mq.h <- reading_MQ(system.file("extdata", "proteinGroups_human.txt", package = "DepLab"))
#  mq.h.clean <- cleaning_MQ(mq.h, remove.contaminants = TRUE, remove.decoys = TRUE, poi = "human")
#  ids.list <- info_from_fastaHeader(mq.h.clean$Fasta.headers, routine = "human")
#  mq.h.raw.intensity <- MQ_to_longFormat(mq.h.clean, y = "raw.intensity", ids.list)
#  head(mq.h.raw.intensity)

## ----checkDB-------------------------------------------------------------
#  database.name <- system.file("inst", "proteomics.db", package = "DepLab")
#  filename <- system.file("extdata", "proteinGroups_100mM_new.txt", package = "DepLab")
#  expt.id <- "pg_100mM"
#  
#  ##Create the database, and completely overwrite if it already exists (useful for debugging!)
#  initialize.database(database.name, organism.name = "yeast", force = TRUE)
#  
#  ## Adds an experiment to the database. To initially populate the database, you can call this for the three examples from the command line, but should be what is called from the Save button on the Input tab.
#  x <- read.MQ.data(filename, expt.id, organism = "yeast")
#  head(x)
#  
#  # testing the manual input of protein IDs
#  y <- read.MQ.data(filename, expt.id, organism = NULL, data.subset = c("P07477", "Q0140","YAL003W"))
#  head(y)
#  
#  # This currently breaks because std.data is not yet implemented.
#  # add.expt.to.database(database.name, data.frame(expt_id = expt.id), NULL, x)

## ----checkNorm-----------------------------------------------------------
#  mq.y.1 <- read.MQ.data(filename = system.file("extdata", "proteinGroups_100mM_new.txt", package = "DepLab"), expt.id = "100mM", data.subset = "poi", organism = "yeast")
#  mq.y.3 <- read.MQ.data(filename = system.file("extdata", "proteinGroups_300mM_new.txt", package = "DepLab"), expt.id = "300mM", data.subset = "poi", organism = "yeast")
#  mqcombi <- rbind(mq.y.1, mq.y.3)
#  fraction.norm <- normalize_values(long.df = subset(mqcombi, measurement == "raw.intensity"),
#                                    norm.type = "fraction", prot.identifier = "gene_symbol")

